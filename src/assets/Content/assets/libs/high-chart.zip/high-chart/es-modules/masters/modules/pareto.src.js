/**
 * @license Highcharts JS v10.1.0 (2022-04-29)
 * @module highcharts/modules/pareto
 * @requires highcharts
 *
 * Pareto series type for Highcharts
 *
 * (c) 2010-2021 Sebastian Bochan
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/ParetoSeries/ParetoSeries.js';
