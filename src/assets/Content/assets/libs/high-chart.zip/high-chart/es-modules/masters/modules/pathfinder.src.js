/**
 * @license Highcharts Gantt JS v10.1.0 (2022-04-29)
 * @module highcharts/modules/pathfinder
 * @requires highcharts
 *
 * Pathfinder
 *
 * (c) 2016-2021 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Gantt/Pathfinder.js';
